# 🚗 EV Sales Prediction Project

This repository is a starter project for **Electric Vehicle (EV) Sales Prediction** using Machine Learning and Streamlit.
It includes a sample dataset, a Jupyter notebook with EDA and model training, and a Streamlit app to explore and predict.

## Files
- `data/ev_sales_sample.csv` - small synthetic sample dataset for testing.
- `notebooks/EV_Sales_Prediction.ipynb` - Jupyter notebook with EDA, preprocessing, model training and saving.
- `app/app.py` - Streamlit application to interact with the dataset and model.
- `requirements.txt` - Python dependencies.
- `README.md` - this file.

## Use a real Kaggle dataset
1. Download a suitable EV dataset from Kaggle (search "electric vehicle sales", "EV dataset").
2. Place your downloaded CSV into `data/` and rename to `ev_sales.csv` (or update paths in the notebook/app).

## Quick start (local)
```bash
# create and activate venv (optional)
python -m venv venv
source venv/bin/activate  # mac/linux
venv\Scripts\activate     # windows

pip install -r requirements.txt
jupyter notebook notebooks/EV_Sales_Prediction.ipynb
# or run the Streamlit app
streamlit run app/app.py
```

