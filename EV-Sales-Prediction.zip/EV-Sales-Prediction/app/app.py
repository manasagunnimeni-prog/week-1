import streamlit as st
import pandas as pd
import numpy as np
import os
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

st.set_page_config(page_title="EV Sales Prediction", layout="wide")

st.title("🚗 EV Sales Prediction - Streamlit App (Starter)")
st.markdown("Upload an EV sales CSV or use the sample dataset included. Then train a simple model and predict sales.")

DATA_PATH = os.path.join("..","data","ev_sales_sample.csv")
uploaded = st.file_uploader("Upload CSV", type=["csv"])

if uploaded is not None:
    df = pd.read_csv(uploaded)
else:
    try:
        df = pd.read_csv(os.path.join("..","data","ev_sales_sample.csv"))
    except FileNotFoundError:
        st.error("Sample dataset not found. Please upload a CSV.")
        st.stop()

st.subheader("Dataset (preview)")
st.dataframe(df.head())

if st.checkbox("Show basic statistics"):
    st.write(df.describe(include='all'))

# Simple preprocessing helper
def preprocess(df):
    df2 = df.copy()
    # keep numeric columns: Year, Price, Battery_kWh, Range_km, Sales
    # try to standardize column names
    colmap = {}
    for c in df2.columns:
        lc = c.lower()
        if "price" in lc:
            colmap[c] = "Price"
        if "battery" in lc or "kwh" in lc:
            colmap[c] = "Battery_kWh"
        if "range" in lc:
            colmap[c] = "Range_km"
        if "sales" in lc:
            colmap[c] = "Sales"
        if "year" in lc:
            colmap[c] = "Year"
    df2 = df2.rename(columns=colmap)
    # Drop rows with missing Sales or Price
    df2 = df2.dropna(subset=["Sales"])
    # Fill numeric NaNs with mean
    for col in ["Price","Battery_kWh","Range_km","Year"]:
        if col in df2.columns:
            df2[col] = pd.to_numeric(df2[col], errors='coerce')
            df2[col] = df2[col].fillna(df2[col].mean())
    # One-hot encode Brand if present
    if "Brand" in df2.columns:
        df2 = pd.get_dummies(df2, columns=["Brand"], drop_first=True)
    return df2

if st.button("Preprocess & Train Model"):
    with st.spinner("Preprocessing dataset..."):
        df_p = preprocess(df)
        st.write("Preprocessed shape:", df_p.shape)
        st.write(df_p.head())
    with st.spinner("Training model..."):
        # prepare X and y
        if "Sales" not in df_p.columns:
            st.error("No 'Sales' column found after preprocessing. Make sure your CSV has a sales column.")
        else:
            X = df_p.drop(["Sales","Model"], axis=[0,0], errors='ignore')
            y = df_p["Sales"].astype(float)
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            model = RandomForestRegressor(n_estimators=100, random_state=42)
            model.fit(X_train, y_train)
            preds = model.predict(X_test)
            mse = mean_squared_error(y_test, preds)
            r2 = r2_score(y_test, preds)
            st.success(f"Model trained. Test MSE: {mse:.2f}, R2: {r2:.2f}")
            joblib.dump(model, "model.pkl")
            st.info("Saved model as model.pkl in current directory.")

if os.path.exists("model.pkl"):
    st.subheader("Predict using saved model")
    model = joblib.load("model.pkl")
    # minimal UI for prediction: ask for numeric inputs
    st.write("Enter inputs to predict Sales (use Year, Price, Battery_kWh, Range_km, and optional Brand columns).")
    col1, col2 = st.columns(2)
    with col1:
        year = st.number_input("Year", value=2024)
        price = st.number_input("Price", value=30000)
    with col2:
        battery = st.number_input("Battery_kWh", value=50.0)
        rng = st.number_input("Range_km", value=300.0)
    # Prepare input array (no brand dummies here)
    x = np.array([[year, price, battery, rng]])
    try:
        pred = model.predict(x)
        st.metric("Predicted Sales", f"{pred[0]:.0f} units")
    except Exception as e:
        st.error("Prediction failed: " + str(e))